package com.voidbloom.block;

import com.mojang.serialization.MapCodec;
import com.voidbloom.registry.ModBlockEntities;
import com.voidbloom.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Горн резонанса — контроллер мультиблока с интерфейсом (как варочная стойка).
 * Схема (относительно горна):
 *  y-1: платформа 3x3 из эхо-кирпичей, в центре под горном — магма-блок;
 *  по углам на расстоянии 2: столб из эхо-кирпича (y0) + блок эхо-кристалла (y1);
 *  по сторонам на расстоянии 2 (y0): плачущий обсидиан; над горном (y+1) свободно.
 */
public class ResonanceForgeBlock extends Block implements EntityBlock {
    public static final MapCodec<ResonanceForgeBlock> CODEC = simpleCodec(ResonanceForgeBlock::new);

    public ResonanceForgeBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    /** Возвращает число неверных блоков в схеме. */
    public static int countMistakes(Level level, BlockPos core) {
        int bad = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                Block want = (dx == 0 && dz == 0) ? Blocks.MAGMA_BLOCK : ModBlocks.ECHO_BRICKS.get();
                if (!level.getBlockState(core.offset(dx, -1, dz)).is(want)) bad++;
            }
        }
        for (int sx = -2; sx <= 2; sx += 4) {
            for (int sz = -2; sz <= 2; sz += 4) {
                if (!level.getBlockState(core.offset(sx, 0, sz)).is(ModBlocks.ECHO_BRICKS.get())) bad++;
                if (!level.getBlockState(core.offset(sx, 1, sz)).is(ModBlocks.ECHO_CRYSTAL_BLOCK.get())) bad++;
            }
        }
        int[][] sides = {{2, 0}, {-2, 0}, {0, 2}, {0, -2}};
        for (int[] s : sides) {
            if (!level.getBlockState(core.offset(s[0], 0, s[1])).is(Blocks.CRYING_OBSIDIAN)) bad++;
        }
        if (!level.getBlockState(core.above()).isAir()) bad++;
        return bad;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        int bad = countMistakes(level, pos);
        if (bad > 0) {
            player.displayClientMessage(Component.translatable("message.voidbloom.forge_bad", bad), true);
            return InteractionResult.CONSUME;
        }
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof ResonanceForgeBlockEntity forge && player instanceof ServerPlayer sp) {
            forge.recheck();
            sp.openMenu(forge, pos);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ResonanceForgeBlockEntity(pos, state);
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide || type != ModBlockEntities.RESONANCE_FORGE.get()) return null;
        return (BlockEntityTicker<T>) (BlockEntityTicker<ResonanceForgeBlockEntity>) ResonanceForgeBlockEntity::tick;
    }

    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock())) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof ResonanceForgeBlockEntity forge) {
                Containers.dropContents(level, pos, forge);
            }
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }
}
