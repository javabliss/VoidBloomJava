package com.voidbloom.item;

import com.voidbloom.VoidbloomMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.Structure;

/** Эхо-компас: ПКМ показывает направление и расстояние до ближайшего Святилища или Хранилища. */
public class EchoCompassItem extends Item {
    private static final TagKey<Structure> TARGETS =
            TagKey.create(Registries.STRUCTURE, VoidbloomMod.id("echo_compass_targets"));

    public EchoCompassItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.sidedSuccess(stack, true);
        if (level.dimension() != VoidbloomMod.ECHO_EXPANSE) {
            player.displayClientMessage(Component.translatable("message.voidbloom.compass_wrong"), true);
            return InteractionResultHolder.fail(stack);
        }
        ServerLevel server = (ServerLevel) level;
        BlockPos found = server.findNearestMapStructure(TARGETS, player.blockPosition(), 100, false);
        if (found == null) {
            player.displayClientMessage(Component.translatable("message.voidbloom.compass_none"), true);
        } else {
            double dx = found.getX() - player.getX();
            double dz = found.getZ() - player.getZ();
            int dist = (int) Math.sqrt(dx * dx + dz * dz);
            String[] names = {"В", "ЮВ", "Ю", "ЮЗ", "З", "СЗ", "С", "СВ"};
            int idx = (int) Math.round(Math.toDegrees(Math.atan2(dz, dx)) / 45.0D);
            String dir = names[Math.floorMod(idx, 8)];
            player.displayClientMessage(Component.translatable("message.voidbloom.compass_found", dist, dir), true);
            stack.hurtAndBreak(1, player, net.minecraft.world.entity.EquipmentSlot.MAINHAND);
        }
        player.getCooldowns().addCooldown(this, 40);
        return InteractionResultHolder.success(stack);
    }
}
