package com.voidbloom.entity;

import com.voidbloom.registry.ModEntities;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Повелитель Эха — босс.
 * Фаза 1: тяжёлые удары и ударная волна каждые 6 секунд.
 * Фаза 2 (меньше 50% здоровья): ускорение и призыв осколочников каждые 15 секунд.
 */
public class EchoSovereignEntity extends Monster {
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.translatable("entity.voidbloom.echo_sovereign"),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.NOTCHED_10);

    private int waveCooldown = 120;
    private int summonCooldown = 200;

    public EchoSovereignEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 250;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.ARMOR, 8.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, true));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, false));
    }

    private boolean isPhaseTwo() {
        return getHealth() < getMaxHealth() * 0.5F;
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(getHealth() / getMaxHealth());

        LivingEntity target = getTarget();
        if (target == null) return;

        if (waveCooldown > 0) waveCooldown--;
        if (waveCooldown == 0 && distanceToSqr(target) < 100.0D) {
            shockwave();
            waveCooldown = isPhaseTwo() ? 80 : 120;
        }

        if (isPhaseTwo()) {
            addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 1, false, false));
            if (summonCooldown > 0) summonCooldown--;
            if (summonCooldown == 0) {
                summonMinions();
                summonCooldown = 300;
            }
        }
    }

    private void shockwave() {
        ServerLevel server = (ServerLevel) level();
        List<Player> victims = server.getEntitiesOfClass(Player.class, getBoundingBox().inflate(7.0D, 2.0D, 7.0D));
        for (Player p : victims) {
            if (p.isCreative() || p.isSpectator()) continue;
            p.hurt(damageSources().mobAttack(this), 7.0F);
            Vec3 push = p.position().subtract(position()).multiply(1, 0, 1).normalize().scale(1.4D);
            p.setDeltaMovement(push.x, 0.5D, push.z);
            p.hurtMarked = true;
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0));
        }
        server.sendParticles(ParticleTypes.SONIC_BOOM, getX(), getY() + 1.0D, getZ(), 1, 0, 0, 0, 0);
        for (int i = 0; i < 48; i++) {
            double a = i * Math.PI * 2.0D / 48.0D;
            server.sendParticles(ParticleTypes.DRAGON_BREATH, getX() + Math.cos(a) * 5.0D, getY() + 0.2D,
                    getZ() + Math.sin(a) * 5.0D, 1, 0, 0.1, 0, 0.02);
        }
        server.playSound(null, blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.HOSTILE, 3.0F, 0.6F);
    }

    private void summonMinions() {
        ServerLevel server = (ServerLevel) level();
        for (int i = 0; i < 2; i++) {
            ShardlingEntity minion = ModEntities.SHARDLING.get().create(server);
            if (minion == null) continue;
            double a = random.nextDouble() * Math.PI * 2.0D;
            minion.moveTo(getX() + Math.cos(a) * 3.0D, getY(), getZ() + Math.sin(a) * 3.0D, random.nextFloat() * 360.0F, 0);
            minion.finalizeSpawn(server, server.getCurrentDifficultyAt(blockPosition()), MobSpawnType.MOB_SUMMONED, null);
            if (getTarget() != null) minion.setTarget(getTarget());
            server.addFreshEntity(minion);
        }
        server.playSound(null, blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON, SoundSource.HOSTILE, 2.0F, 0.8F);
    }

    // --- Босс-бар ---
    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void setCustomName(Component name) {
        super.setCustomName(name);
        bossEvent.setName(getDisplayName());
    }

    @Override
    public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (hasCustomName()) {
            bossEvent.setName(getDisplayName());
        }
    }

    // --- Прочее ---
    @Override
    public boolean canUsePortal(boolean allowPassengers) {
        return false;
    }

    @Override
    protected boolean canRide(net.minecraft.world.entity.Entity vehicle) {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.WARDEN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WARDEN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WARDEN_DEATH;
    }
}
