package com.voidbloom;

import com.voidbloom.registry.ModArmor;
import com.voidbloom.registry.ModBlocks;
import com.voidbloom.registry.ModEntities;
import com.voidbloom.registry.ModItems;
import com.voidbloom.registry.ModTabs;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(VoidbloomMod.MODID)
public class VoidbloomMod {
    public static final String MODID = "voidbloom";

    /** Ключ нового измерения: data/voidbloom/dimension/echo_expanse.json */
    public static final ResourceKey<Level> ECHO_EXPANSE =
            ResourceKey.create(Registries.DIMENSION, id("echo_expanse"));

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }

    public VoidbloomMod(IEventBus modBus) {
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModArmor.MATERIALS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModTabs.TABS.register(modBus);
        com.voidbloom.registry.ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        com.voidbloom.registry.ModMenus.MENUS.register(modBus);
    }
}
