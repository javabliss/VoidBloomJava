package com.voidbloom.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.voidbloom.VoidbloomMod;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.DimensionSpecialEffects;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** Собственное небо Эхо-Бездны: розово-бирюзовый градиент, огромная аметистовая луна и переливающееся сияние. */
public class EchoSkyEffects extends DimensionSpecialEffects {
    private static final ResourceLocation MOON = VoidbloomMod.id("textures/environment/echo_moon.png");
    private static final ResourceLocation AURORA = VoidbloomMod.id("textures/environment/echo_aurora.png");

    public EchoSkyEffects() {
        super(192.0F, true, SkyType.NORMAL, false, false);
    }

    @Override
    public Vec3 getBrightnessDependentFogColor(Vec3 color, float brightness) {
        return new Vec3(1.0D, 0.80D, 0.93D);
    }

    @Override
    public boolean isFoggyAt(int x, int y) {
        return false;
    }

    private static void v(BufferBuilder b, Matrix4f m, float x, float y, float z, int r, int g, int bl) {
        b.addVertex(m, x, y, z).setColor(r, g, bl, 255);
    }

    @Override
    public boolean renderSky(ClientLevel level, int ticks, float partialTick, Matrix4f mv, Camera camera,
                             Matrix4f projection, boolean isFoggy, Runnable setupFog) {
        setupFog.run();
        RenderSystem.disableBlend();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        float s = 100.0F;
        // небесный купол: зенит сиренево-розовый, у горизонта бирюзово-кремовый
        int[] top = {196, 150, 255}, mid = {255, 170, 225}, low = {170, 255, 240};
        BufferBuilder b = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        v(b, mv, -s, s, -s, top[0], top[1], top[2]); v(b, mv, -s, s, s, top[0], top[1], top[2]);
        v(b, mv, s, s, s, top[0], top[1], top[2]); v(b, mv, s, s, -s, top[0], top[1], top[2]);
        float[][] sides = {{-s, -s, s, -s}, {s, -s, s, s}, {s, s, -s, s}, {-s, s, -s, -s}};
        for (float[] e : sides) {
            v(b, mv, e[0], s * 0.25F, e[1], mid[0], mid[1], mid[2]);
            v(b, mv, e[2], s * 0.25F, e[3], mid[0], mid[1], mid[2]);
            v(b, mv, e[2], -s * 0.25F, e[3], low[0], low[1], low[2]);
            v(b, mv, e[0], -s * 0.25F, e[1], low[0], low[1], low[2]);
            v(b, mv, e[0], s, e[1], top[0], top[1], top[2]);
            v(b, mv, e[2], s, e[3], top[0], top[1], top[2]);
            v(b, mv, e[2], s * 0.25F, e[3], mid[0], mid[1], mid[2]);
            v(b, mv, e[0], s * 0.25F, e[1], mid[0], mid[1], mid[2]);
        }
        v(b, mv, -s, -s * 0.25F, -s, low[0], low[1], low[2]); v(b, mv, s, -s * 0.25F, -s, low[0], low[1], low[2]);
        v(b, mv, s, -s * 0.25F, s, low[0], low[1], low[2]); v(b, mv, -s, -s * 0.25F, s, low[0], low[1], low[2]);
        BufferUploader.drawWithShader(b.buildOrThrow());

        float t = (ticks + partialTick);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        // сияние
        RenderSystem.setShaderTexture(0, AURORA);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 0.55F + 0.25F * (float) Math.sin(t * 0.01F));
        BufferBuilder a = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
        float h = 60.0F, shift = (t * 0.0006F) % 1.0F;
        for (int i = 0; i < 4; i++) {
            float[] e = sides[i];
            a.addVertex(mv, e[0], h + 25, e[1]).setUv(shift, 0);
            a.addVertex(mv, e[2], h + 25, e[3]).setUv(shift + 0.25F, 0);
            a.addVertex(mv, e[2], 5, e[3]).setUv(shift + 0.25F, 1);
            a.addVertex(mv, e[0], 5, e[1]).setUv(shift, 1);
        }
        BufferUploader.drawWithShader(a.buildOrThrow());
        // луна
        RenderSystem.setShaderTexture(0, MOON);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        BufferBuilder m = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
        float ms = 28.0F, my = 90.0F, ox = 30.0F;
        m.addVertex(mv, -ms + ox, my, -ms).setUv(0, 0);
        m.addVertex(mv, -ms + ox, my, ms).setUv(0, 1);
        m.addVertex(mv, ms + ox, my, ms).setUv(1, 1);
        m.addVertex(mv, ms + ox, my, -ms).setUv(1, 0);
        BufferUploader.drawWithShader(m.buildOrThrow());
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
        return true;
    }
}
