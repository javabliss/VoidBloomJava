package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.List;
import java.util.function.Supplier;

public class ModArmor {
    public static final DeferredRegister<ArmorMaterial> MATERIALS =
            DeferredRegister.create(BuiltInRegistries.ARMOR_MATERIAL, VoidbloomMod.MODID);

    /** Текстуры: textures/models/armor/echo_layer_1.png и echo_layer_2.png */
    public static final Holder<ArmorMaterial> ECHO = MATERIALS.register("echo", () -> new ArmorMaterial(
            makeDefense(),
            18,
            SoundEvents.ARMOR_EQUIP_DIAMOND,
            () -> Ingredient.of(ModItems.ECHO_CRYSTAL.get()),
            List.of(new ArmorMaterial.Layer(VoidbloomMod.id("echo"))),
            2.5F,
            0.05F));

    public static final Holder<ArmorMaterial> RESONITE = MATERIALS.register("resonite", () -> new ArmorMaterial(
            makeResoniteDefense(),
            22,
            SoundEvents.ARMOR_EQUIP_NETHERITE,
            () -> Ingredient.of(ModItems.RESONITE_INGOT.get()),
            List.of(new ArmorMaterial.Layer(VoidbloomMod.id("resonite"))),
            4.0F,
            0.15F));

    private static EnumMap<ArmorItem.Type, Integer> makeResoniteDefense() {
        EnumMap<ArmorItem.Type, Integer> map = new EnumMap<>(ArmorItem.Type.class);
        map.put(ArmorItem.Type.BOOTS, 4);
        map.put(ArmorItem.Type.LEGGINGS, 7);
        map.put(ArmorItem.Type.CHESTPLATE, 9);
        map.put(ArmorItem.Type.HELMET, 4);
        map.put(ArmorItem.Type.BODY, 13);
        return map;
    }

    private static EnumMap<ArmorItem.Type, Integer> makeDefense() {
        EnumMap<ArmorItem.Type, Integer> map = new EnumMap<>(ArmorItem.Type.class);
        map.put(ArmorItem.Type.BOOTS, 3);
        map.put(ArmorItem.Type.LEGGINGS, 6);
        map.put(ArmorItem.Type.CHESTPLATE, 8);
        map.put(ArmorItem.Type.HELMET, 3);
        map.put(ArmorItem.Type.BODY, 11);
        return map;
    }
}
