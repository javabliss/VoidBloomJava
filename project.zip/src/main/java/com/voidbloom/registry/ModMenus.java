package com.voidbloom.registry;

import com.voidbloom.VoidbloomMod;
import com.voidbloom.menu.ResonanceForgeMenu;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU, VoidbloomMod.MODID);

    public static final DeferredHolder<MenuType<?>, MenuType<ResonanceForgeMenu>> RESONANCE_FORGE =
            MENUS.register("resonance_forge", () -> IMenuTypeExtension.create(ResonanceForgeMenu::new));
}
