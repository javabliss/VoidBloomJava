package com.voidbloom.registry;

import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.common.SimpleTier;

public class ModTiers {
    /** Чуть лучше алмаза по скорости и урону, прочность ниже незерита. */
    public static final Tier ECHO = new SimpleTier(
            BlockTags.INCORRECT_FOR_DIAMOND_TOOL,
            1800,
            8.5F,
            3.5F,
            18,
            () -> Ingredient.of(ModItems.ECHO_CRYSTAL.get()));

    /** Выше незерита: прочность 3600, скорость 10, урон +5. */
    public static final Tier RESONITE = new SimpleTier(
            BlockTags.INCORRECT_FOR_NETHERITE_TOOL,
            3600,
            10.0F,
            5.0F,
            22,
            () -> Ingredient.of(ModItems.RESONITE_INGOT.get()));
}
